#include "socket.hpp"
#include <stdio.h>
#include <errno.h>

int main(int argc, char* argv[]){
		int port;
		SocketUDP* mioSocket;
		Address* dest;
		char* ip;
		char* msg;
		
		if(argc!=4){
			printf("USAGE %s IP PORT MESSAGE\n", argv[0]);
			return(-1);
		}
		
		ip = argv[1];
		port = atoi(argv[2]);
		msg = argv[3];
		
		mioSocket = new SocketUDP("0.0.0.0", 5555, true);
		dest = new Address(ip, port);
		mioSocket->invia(*dest, msg);
		
		//printf("%s\n", strerror(errno));
}
